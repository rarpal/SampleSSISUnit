﻿CREATE TABLE [staging].[Contacts]
(
	[Number] INT NOT NULL , 
    [Name] VARCHAR(60) NULL, 
    [Telephone] VARCHAR(60) NULL, 
    [Address] VARCHAR(200) NULL, 
    [AddressDate] DATE NULL
)
